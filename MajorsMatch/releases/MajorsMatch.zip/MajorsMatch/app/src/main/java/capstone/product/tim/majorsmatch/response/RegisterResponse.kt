package capstone.product.tim.majorsmatch.response

data class RegisterResponse(
	val error: Boolean? = null,
	val message: String? = null
)

