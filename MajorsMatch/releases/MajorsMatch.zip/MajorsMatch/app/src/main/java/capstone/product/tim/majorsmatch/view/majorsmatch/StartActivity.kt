package capstone.product.tim.majorsmatch.view.majorsmatch

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import capstone.product.tim.majorsmatch.R

class StartActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_start)
    }
}